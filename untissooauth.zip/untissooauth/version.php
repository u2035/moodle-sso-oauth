<?php
	defined('MOODLE_INTERNAL') || die();

	$plugin->version = 2019042200;
	$plugin->requires = 2017111308;   // Requires Moodle 2.7 or later.
	$plugin->release = '1.0';
	$plugin->maturity = MATURITY_STABLE;             // This version's maturity level.
	$plugin->component = 'auth_untissooauth'; // Declare the type and name of this plugin.

