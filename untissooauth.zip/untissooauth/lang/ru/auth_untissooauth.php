<?php

	$string[ 'pluginname' ] = 'УНТИ SSO OAuth';

	$string[ 'auth_untissooauthdescription' ] = 'Аутентификация с помощью SSO УНТИ';
	$string[ 'invalid_code_param' ] = 'Не был получен код авторизации';
	$string[ 'invalid_state_param' ] = 'Параметр state неверный';
	$string[ 'could_not_get_access_token' ] = 'Не удалось получить access token';
	$string[ 'invalid_response' ] = 'Получен некорректный ответ';
	$string[ 'login_with_unti' ] = 'Войти с помощью “20.35”';

	$string[ 'config_client_id' ] = 'УНТИ SSO client ID';
	$string[ 'config_client_secret' ] = 'УНТИ SSO client secret';
	$string[ 'config_auth_url' ] = 'УНТИ SSO URL для авторизации';
